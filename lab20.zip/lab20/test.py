"""
A test script for lab20

Run this test script to make sure everything is working properly.

Author: Walker White (wmw2)
Date:   November 2, 2018
"""
import introcs
import lab20


def test_get_previous():
    """
    Tests the get_previous function
    """
    print('Testing the function get_previous')

    introcs.assert_equals(22,   lab20.get_previous('file_good.txt'))
    introcs.assert_equals('ABC',lab20.get_previous('file_bad.txt'))
    introcs.assert_equals(None, lab20.get_previous('file_huh.txt'))

    fail = False
    try:
        lab20.get_previous(12)
        fail = True
    except AssertionError:
        pass
    except:
        introcs.quit_with_error('Function get_previous is not enforcing preconditions.')

    if fail:
        introcs.quit_with_error('Function get_previous is not enforcing preconditions.')



def test_limited_error():
    """
    Tests the LimitedUnavailableError class
    """
    print('Testing the class LimitedUnavailableError')

    if not hasattr(lab20,'LimitedUnavailableError'):
        introcs.quit_with_error('lab20 is missing the class LimitedUnavailableError.')

    if type(lab20.LimitedUnavailableError) != type:
        introcs.quit_with_error('LimitedUnavailableError is not a class.')

    introcs.assert_equals((1,), lab20.LimitedUnavailableError(1).args)
    introcs.assert_equals((1,2),lab20.LimitedUnavailableError(1,2).args)


def test_limited_class():
    """
    Tests the initializer of the class Limited
    """
    print('Testing the class Limited')

    introcs.assert_equals(1,lab20.Limited(1).x)
    introcs.assert_equals(3,lab20.Limited.AVAILABLE)
    introcs.assert_equals(2,lab20.Limited(2).x)
    introcs.assert_equals(2,lab20.Limited.AVAILABLE)
    introcs.assert_equals(3,lab20.Limited(3).x)
    introcs.assert_equals(1,lab20.Limited.AVAILABLE)
    introcs.assert_equals(4,lab20.Limited(4).x)
    introcs.assert_equals(0,lab20.Limited.AVAILABLE)

    fail = False
    try:
        lab20.Limited(1)
        fail = True
    except lab20.LimitedUnavailableError:
        pass
    except:
        introcs.quit_with_error('Limited raised an error other than LimitedUnavailableError')
    if fail:
        introcs.quit_with_error('Limited continued to create objects after the AVAILABLE is 0')

    fail = False
    try:
        lab20.Limited('a')
        fail = True
    except lab20.LimitedUnavailableError:
        introcs.quit_with_error('The initializer for Limited is not enforcing preconditions.')
    except AssertionError:
        pass
    if fail:
        introcs.quit_with_error('The initializer for Limited is not enforcing preconditions.')


def test_point2_equals1():
    """
    Tests the equals1 method of class Point2.
    """
    print('Testing the method equals1 in Point2')

    class SubPoint(lab20.Point2):
        """Subclass to test"""
        pass

    p = lab20.Point2(1,2)
    introcs.assert_true(p.equals1(p))
    introcs.assert_true(p.equals1(lab20.Point2(1,2)))
    introcs.assert_false(p.equals1(lab20.Point2(1,4)))
    introcs.assert_false(p.equals1(lab20.Point2(3,2)))
    introcs.assert_false(p.equals1(lab20.Point2(3,4)))
    introcs.assert_false(p.equals1(2))
    introcs.assert_true(p.equals1(SubPoint(1,2)))


def test_point2_equals2():
    """
    Tests the equals2 method of class Point2.
    """
    print('Testing the method equals2 in Point2')

    class SubPoint(lab20.Point2):
        """Subclass to test"""
        pass

    class Foo(object):
        """Duck class to test"""
        def __init__(self,x,y,z):
            """Initialize with three attributes"""
            self.x = x
            self.y = y
            self.z = z

    p = lab20.Point2(1,2)
    introcs.assert_true(p.equals2(p))
    introcs.assert_true(p.equals2(lab20.Point2(1,2)))
    introcs.assert_false(p.equals2(lab20.Point2(1,4)))
    introcs.assert_false(p.equals2(lab20.Point2(3,2)))
    introcs.assert_false(p.equals2(lab20.Point2(3,4)))
    introcs.assert_false(p.equals2(2))
    introcs.assert_true(p.equals2(SubPoint(1,2)))
    introcs.assert_true(p.equals2(Foo(1,2,3)))


def test_replace_copy():
    """
    Tests the function replace_copy
    """
    print('Testing replace_copy')
    introcs.assert_equals([4], lab20.replace_copy([5],5,4))
    introcs.assert_equals([], lab20.replace_copy([], 1, 2))
    mylist = [5, 3, 3455, 74, 74, 74, 3]
    introcs.assert_equals([5, 20, 3455, 74, 74, 74, 20], lab20.replace_copy(mylist,3, 20))
    introcs.assert_equals([5, 3, 3455, 74, 74, 74, 3], lab20.replace_copy(mylist, 1, 3))
    print('  replace_copy looks okay')


def test_replace():
    """
    Tests the function replace
    """
    print('Testing replace')
    mylist = [5]
    lab20.replace(mylist,5,4)
    introcs.assert_equals([4], mylist)

    mylist = []
    lab20.replace(mylist,1,2)
    introcs.assert_equals([], mylist)

    mylist = [5, 3, 3455, 74, 74, 74, 3]
    lab20.replace(mylist, 3, 20)
    introcs.assert_equals([5, 20, 3455, 74, 74, 74, 20], mylist)

    lab20.replace(mylist, 1, 3)
    introcs.assert_equals([5, 20, 3455, 74, 74, 74, 20], mylist)
    print('  replace looks okay')


# Script code
if __name__ == '__main__':
    test_get_previous()
    test_limited_error()
    test_limited_class()
    test_point2_equals1()
    test_point2_equals2()

    # OPTIONALS.  UNCOMMENT ALL YOU DO
    #test_replace_copy()
    #test_replace()

    print('The module lab20 passed all tests')
