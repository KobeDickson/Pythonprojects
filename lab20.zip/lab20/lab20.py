"""
A module devoted to exceptions and dynamic typing

YOUR NAME AND NETID HERE
THE DATE COMPLETED HERE
"""


# PART 1
def get_previous(filename):
    """
    Returns the number before the one stored in the file filename.

    By number before, we mean that the number is an int, and the result subtracts one
    from the int in the file.

    If the file does not contain an int, this function returns the contents of the file.

    If the file does not exist or cannot be opened, this function returns None.

    Parameter filename: The name of the file to open
    Precondition: filename is a string
    """
    # IMPLEMENT ME
    pass


# Part 2
# IMPLEMENT A NEW EXCEPTION CALLED LimitedUnavailableError HERE



class Limited(object):
    """
    A class that only allows you to make a limited number of objects.

    This class has a class attribute named AVAILABLE.  Every time an object is
    created, this attribute is decremented by one.  When each reaches 0, no more
    objects can be created.  Further constructor calls will raise a
    LimitedUnavailableError.

    INSTANCE ATTRIBUTE:
        x: A simple number [int or float]
    """

    # How many objects are left (starts at 4)
    AVAILABLE = 4

    def __init__(self,x):
        """
        Initializes a new Limited object

        The initializer checks to see if the object can be created (is AVAILABLE > 0).
        If so, it creates  a new object with attribute x and decrements AVAILABLE by 1.
        Otherwise, it raises a LimitedUnavailableError with x as the error.

        Parameter x: The object x value
        Precondition: x is an int or float
        """
        # IMPLEMENT ME
        pass


# Part 3
class Point2(object):
    """
    A class to represent a point in 2D space

    Attribute x: the x-coordinate
    Invariant: x is a float

    Attribute y: the x-coordinate
    Invariant: y is a float
    """

    def __init__(self,x,y):
        """
        Initializes a new Point

        Parameter x: The x-coordinate
        Precondition: x is a float

        Parameter y: The y-coordinate
        Precondition: y is a float
        """
        assert type(x) in [int,float], '%s is not a number' % repr(x)
        assert type(y) in [int,float], '%s is not a number' % repr(y)
        self.x = x
        self.y = y

    def equals1(self,other):
        """
        Returns True if other is an instance of Point2 and equal to this one.

        Two points are equivalent if they share the same x and y values.

        Parameter other: The object to compare
        Precondition: other can be anything
        """
        # IMPLEMENT ME
        pass

    def equals2(self,other):
        """
        Returns True if other is duck-equivalent to this Point2.

        An object is duck-equivalent to a Point2 object if (1) it has attributes x
        and y and (2) those values are the same as this object.

        Parameter other: The object to compare
        Precondition: other can be anything
        """
        # IMPLEMENT ME
        pass


# OPTIONAL FUNCTIONS
# PART 4
def replace_copy(thelist,a,b):
    """
    Returns a COPY of thelist but with all occurrences of a replaced by b.

    Example: replace([1,2,3,1], 1, 4) is [4,2,3,4].

    Parameter thelist: list to search
    Precondition: thelist is a list of ints

    Parameter a: value to search for
    Precondition: a is an int

    Parameter b: value to replace
    Precondition: b is an int
    """
    copy = []  # Accumulator
    k = 0      # Loop variable

    # IMPLEMENT A WHILE LOOP HERE

    # END WHILE LOOP

    # Return result
    return copy


def replace(thelist,a,b):
    """
    MODIFIES thelist so that all occurrences of a are replaced by b.

    This function should have NO RETURN STATEMENT

    Example: if a = [1,2,3,1] then a becomes [4,2,3,4] after the
    function call replace(a,1,4).

    Parameter thelist: list to search
    Precondition: thelist is a list of ints

    Parameter a: value to search for
    Precondition: a is an int

    Parameter b: value to replace
    Precondition: b is an int
    """
    # IMPLEMENT A WHILE LOOP HERE

    # END WHILE LOOP

    pass
