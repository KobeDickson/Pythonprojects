"""
A simple application (and moving) a composite object

The purpose of this lab is to help you understand how to combine objects in the game2d 
package. Once you finish this, you should be able to do all of Task 1.

<YOUR NAME HERE>
<DATE HERE>
"""
from game2d import *

#### CONSTANTS ####

# The initial width of the game display
GAME_WIDTH  = 840
# The initial height of the game display
GAME_HEIGHT = 630

# How big to make the heart-eyes image
IMAGE_WIDTH  = 96
IMAGE_HEIGHT = 96 
# How big to tile the hearts in the background
TILE_WIDTH  = 128
TILE_HEIGHT = 128 

# How far to move the image each frame
MOVE_STEP = 3


class LabApp(GameApp):
    """
    The application class for this lab.
    
    Most of your work in this lab will be done in the composite class GImageTile.
    The only significant work done in this class will be in the update() method.
    """
    # HIDDEN ATTRIBUTES
    # Attribute _comp: The composite object (emoji on a bed of hearts)
    # Invariant: _comp is a GImageTile

    def start(self):
        """
        Initializes the application.

        This method is distinct from the built-in initializer __init__ (which
        you should not override or change). This method is called once the
        game is running.
        """
        self._comp = GImageTile(self.width/2,self.height/2)
        
    def update(self,dt):
        """
        Updates the game objects each frame.
        
        This method is used when we want to change the objects (change the positions or
        add new objects) AFTER the application is initialized.  In this lab, this is
        where you will MOVE the composite object, using the arrow keys
        """
        pass    # Implement me

    def draw(self):
        """
        Draws the game objects to the view.

        Every single thing you want to draw in this game is a GObject. To draw a
        GObject g, simply use the method g.draw(self.view). It is that easy!
        """
        self._comp.draw(self.view)


class GImageTile(object):
    """
    A class representing a composite object of an emoji on a bed of hearts.
    
    The center of the image and the center of the heart tile are always the game.
    """
    # HIDDEN ATTRIBUTES
    # Attribute _tile: The heart tile
    # Invariant: _tile is a GTile; it has the same (x,y) values as _image
    #
    # Attribute _image: The emoji image
    # Invariant: _image is a GImage; it has the same (x,y) values as _tile
    
    # IMPLEMENT GETTERS AND SETTERS WHEN DIRECTED
    
    def __init__(self,x,y):
        """
        Initializes the composite object of the emoji and heart tile
        
        Parameter x: The x-coordinate of the center of both objects
        Precondition: x is a number (int or float)
        
        Parameter y: The y-coordinate of the center of both objects
        Precondition: y is a number (int or float)
        """
        pass    # Implement me
        
    def draw(self,view):
        """
        Draws the emoji on top of the heart tile
        
        Parameter view: The view to draw to
        Precondition: view is a GView object
        """
        pass    # Implement me


# Application code
if __name__ == '__main__':
    # Create and run the lab application
    LabApp(width=GAME_WIDTH,height=GAME_HEIGHT).run()
